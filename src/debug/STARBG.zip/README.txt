@ Made my Darclander
@ If you want to help with any improvements or general comments you can look at 
@ https://github.com/darclander/starBackground which also contains all the source code.


NOTE BEFORE DOING ANYTHING ELSE: I do not take responsibility for any changes / things that
may happen to your computer. Feel free to look through the source code and compile it yourself
if you feel unsure. This is just a project made for fun and not meant to be taken seriously.


StarBG is a simple program for changing your desktop to a moving sky of stars. Usage is simple,
either just launch the application which will have a default of 1920 1080 300 as args
or;

Open a terminal -> 
	Go to the directory StarBG.exe is in ->
		Execute it with arguments ->
ARGS are: WIDTH HEIGHT STARAMOUNT		

EXAMPLE: StarBX.exe 1920 1080 300

NOTE: Be careful with the amount of stars / size of your screen because it can be quite costly.
To stop the animation just kill the application.